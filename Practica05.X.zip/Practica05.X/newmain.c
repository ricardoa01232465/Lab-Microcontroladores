////+++++++++++++++++++++++++++++++++++++| LIBRARIES / HEADERS |+++++++++++++++++++++++++++++++++++++
#include "device_config.h"
#include <math.h>

//+++++++++++++++++++++++++++++++++++++| DIRECTIVES |+++++++++++++++++++++++++++++++++++++
#define _XTAL_FREQ 1000000
#define WAIT_TIME 250
#define BUTTON_RD0 PORTDbits.RD0 //Button S0
#define BUTTON_RD1 PORTDbits.RD1 //Button S0
#define BUTTON_RD2 PORTDbits.RD2 //Button S0
#define BUTTON_RD3 PORTDbits.RD3 //Button S0
#define BUTTON_RD4 PORTDbits.RD4 //Button S0
#define BUTTON_RD5 PORTDbits.RD5 //Button S0
#define BUTTON_RD6 PORTDbits.RD6 //Button S0
#define BUTTON_RD7 PORTDbits.RD7 //Button S0

//+++++++++++++++++++++++++++++++++++++| DATA TYPES |+++++++++++++++++++++++++++++++++++++
enum por_dir{ output, input };              // output = 0, input = 1
enum por_ACDC { digital, analog };          // digital = 0, analog = 1
enum resistor_state { set_ON, res_ON };     // set_ON = 0, res_ON = 1
enum led_state { led_OFF, led_ON };         // led_OFF = 0, led_ON = 1
enum button_state { pushed, no_pushed };     // pushed = 0, no_pushed = 1
int LED_RAND;
int Estatus;
int i = 0;
int n = 8;
int numero = 0x00;

//+++++++++++++++++++++++++++++++++++++| ISRs |+++++++++++++++++++++++++++++++++++++
// ISR for high priority
void __interrupt ( high_priority ) high_isr( void );
// ISR for low priority
void __interrupt ( low_priority ) low_isr( void ); 

//+++++++++++++++++++++++++++++++++++++| FUNCTION DECLARATIONS |+++++++++++++++++++++++++++++++++++++
void portsInit( void );

//+++++++++++++++++++++++++++++++++++++| MAIN |+++++++++++++++++++++++++++++++++++++
void main( void ){
    portsInit();
    LED_RAND = 0;
    Estatus = 0;
    int i = 0;
    int n = 8;
    int numero = 0x00;
    
    while(1){   // Main loop 
        LED_RAND = rand() % 8;             //Gives you a random number from 0 to 7

        encender(LED_RAND);                //Turns Led on randomly
  
        pb_matching(LED_RAND);             // Checks port D status (push bottons) and if true then win!
        __delay_ms(100);
    }
}

//+++++++++++++++++++++++++++++++++++++| FUNCTIONS |+++++++++++++++++++++++++++++++++++++
void portsInit( void ){
    TRISD =  input;                          // Set Port B as output (LEDs)
    ANSELD = digital;                          // Set Port B as digital signal
    PORTD = 0x00;                           // Initial value = OFF
    
    TRISB =  output;                          // Set Port B as output (LEDs)
    ANSELB = digital;                          // Set Port B as digital signal
    PORTB = 0x00;                           // Initial value = OFF
}

int encender( int x ){
switch(x){
        case 0:
        LATB = 0x01;                       // Turn on RB LED   
        __delay_ms(WAIT_TIME);             // Delay function XC8 compiler
            break;

        case 1:
        LATB = 0x02;                       // Turn on RB LED   
        __delay_ms(WAIT_TIME);             // Delay function XC8 compiler
            break;

        case 2:
        LATB = 0x04;                       // Turn on RB LED   
        __delay_ms(WAIT_TIME);             // Delay function XC8 compiler
            break;
        
        case 3:
        LATB = 0x08;                       // Turn on RB LED   
        __delay_ms(WAIT_TIME);             // Delay function XC8 compiler
            break;

        case 4:
        LATB = 0x10;                       // Turn on RB LED   
        __delay_ms(WAIT_TIME);             // Delay function XC8 compiler
            break;

        case 5:
        LATB = 0x20;                       // Turn on RB LED   
        __delay_ms(WAIT_TIME);             // Delay function XC8 compiler
            break;

        case 6:
        LATB = 0x40;                       // Turn on RB LED   
        __delay_ms(WAIT_TIME);             // Delay function XC8 compiler
            break;
        
        case 7:
        LATB = 0x80;                       // Turn on RB LED   
        __delay_ms(WAIT_TIME);             // Delay function XC8 compiler
            break;
            
        break;
            default:
            x = 0;}
}

int knight_rider_effect( int y){
    int i = 0;
    int n = 8;
    int numero = 0x01;
    
    while(y){
       numero = 0x01;
       
       for( i = 0 ; i < n ; i++ ) {
       LATB = numero;
        __delay_ms(75);             // Delay function XC8 compiler 
        numero = numero * 2;
       }

       numero = 0x80;
               
       for( i = 0 ; i < n ; i++ ) {
       LATB = numero;
        __delay_ms(75);             // Delay function XC8 compiler 
        numero = numero / 2;
       } 
   
    }
}

int pb_matching( int a ){
    
       if((BUTTON_RD0 == pushed) & (a == 0))         // If button is pushed and matches current led then
           knight_rider_effect(1);                   // WIN!!
       else                                                 // Otherwise
           encender(a);                              // Keep turning leds on randomly
       
       if((BUTTON_RD1 == pushed) & (a == 1))         // If button is pushed and matches current led then
           knight_rider_effect(1);                   // WIN!!
       else                                                 // Otherwise
          encender(a);                              // Keep turning leds on randomly
       
        if((BUTTON_RD2 == pushed) & (a == 2))         // If button is pushed and matches current led then
           knight_rider_effect(1);                   // WIN!!
       else                                                 // Otherwise
           encender(a);                              // Keep turning leds on randomly
       
        if((BUTTON_RD3 == pushed) & (a == 3))         // If button is pushed and matches current led then
           knight_rider_effect(1);                   // WIN!!
       else                                                 // Otherwise
           encender(a);                              // Keep turning leds on randomly
       
        if((BUTTON_RD4 == pushed) & (a == 4))         // If button is pushed and matches current led then
           knight_rider_effect(1);                   // WIN!!
       else                                                 // Otherwise
           encender(a);                              // Keep turning leds on randomly
       
        if((BUTTON_RD5 == pushed) & (a == 5))         // If button is pushed and matches current led then
           knight_rider_effect(1);                   // WIN!!
       else                                                 // Otherwise
           encender(a);                              // Keep turning leds on randomly
       
        if((BUTTON_RD6 == pushed) & (a == 6))         // If button is pushed and matches current led then
           knight_rider_effect(1);                   // WIN!!
       else                                                 // Otherwise
           encender(a);                              // Keep turning leds on randomly
       
       if((BUTTON_RD7 == pushed) & (a == 7))         // If button is pushed and matches current led then
           knight_rider_effect(1);                   // WIN!!
       else                                                 // Otherwise
           encender(a);   
}